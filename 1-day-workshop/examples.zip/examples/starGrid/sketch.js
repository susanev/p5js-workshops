/* example adapted from p5.js examples */

var gridSize = 35;

function setup() {
  createCanvas(720, 360); 
  background(0); 
  noStroke(); 
  drawGrid();
}

function drawGrid() {
  for (var x = gridSize; x <= width - gridSize; x += gridSize) {
    for (var y = gridSize; y <= height - gridSize; y += gridSize) {
      fill(255);
      rect(x - 1, y - 1, 3, 3);
      stroke(255, 50);
      line(x, y, width / 2, height  /2);
    }
  }
}